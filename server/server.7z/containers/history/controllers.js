const express = require('express');
const router = express.Router();
const services = require('./services');
// routes
// router.post('/create', create);
// router.post('/getAll', getAll);
module.exports = router;